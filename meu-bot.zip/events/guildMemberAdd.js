module.exports = {
  name: "guildMemberAdd",
  execute(member) {
    const channel = member.guild.channels.cache.find(c => c.name === "logs");
    if (!channel) return;

    channel.send(`📥 **${member.user.username} entrou no servidor!**`);
  }
};