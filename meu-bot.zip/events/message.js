module.exports = {
  name: "messageCreate",
  execute(msg, client) {
    if (msg.author.bot) return;

    const prefix = "!";

    if (!msg.content.startsWith(prefix)) return;

    const args = msg.content.slice(prefix.length).split(" ");
    const cmd = args.shift().toLowerCase();

    const command = client.commands.get(cmd);
    if (command) command.run(msg, args, client);
  }
};