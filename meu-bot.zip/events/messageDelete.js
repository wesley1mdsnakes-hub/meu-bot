module.exports = {
  name: "messageDelete",
  execute(msg) {
    const channel = msg.guild.channels.cache.find(c => c.name === "logs");
    if (!channel) return;

    channel.send(`🗑️ **Mensagem apagada:**
Autor: ${msg.author}
Conteúdo: ${msg.content}`);
  }
};