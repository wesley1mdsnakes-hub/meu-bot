module.exports = {
  name: "guildMemberRemove",
  execute(member) {
    const channel = member.guild.channels.cache.find(c => c.name === "logs");
    if (!channel) return;

    channel.send(`📤 **${member.user.username} saiu do servidor.**`);
  }
};