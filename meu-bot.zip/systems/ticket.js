// Sistema de tickets — Arquivo base
module.exports = {
  criarTicket(interaction) {
    interaction.reply("🎫 Sistema de ticket será configurado aqui.");
  }
};