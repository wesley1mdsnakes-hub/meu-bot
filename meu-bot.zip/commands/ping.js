module.exports = {
  name: "ping",
  run(msg) {
    msg.reply("🏓 Pong!");
  }
};